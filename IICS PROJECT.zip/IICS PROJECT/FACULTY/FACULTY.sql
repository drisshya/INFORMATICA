/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [FACULTY_CODE]
      ,[FACULTY_NAME]
      ,[FACULTY_DESIGNATION]
      ,[FACULTY_QUALIFICATION]
  FROM [University Analytics System].[dbo].[FACULTY]
  truncate table CDW_UAS_D_TIME;
  truncate table DEPARTMENT;