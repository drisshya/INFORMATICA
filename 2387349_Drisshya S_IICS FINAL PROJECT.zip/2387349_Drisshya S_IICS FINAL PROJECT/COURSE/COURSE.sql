/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [COURSE_CODE]
      ,[COURSE_NAME]
      ,[DEPARTMENT_NO]
      ,[MARK_REQ]
  FROM [University Analytics System].[dbo].[COURSE]