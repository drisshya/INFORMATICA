/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [TIME_ID]
      ,[DAY]
      ,[MONTH]
      ,[QUARTER]
      ,[YEAR]
  FROM [University Analytics System].[dbo].[CDW_UAS_D_TIME]