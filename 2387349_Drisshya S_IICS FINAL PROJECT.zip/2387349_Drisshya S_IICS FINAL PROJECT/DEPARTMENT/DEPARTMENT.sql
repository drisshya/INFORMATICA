/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [DEPARTMENT_ID]
      ,[DEPARTMENT_NAME]
      ,[DEPARTMENT_NO]
      ,[DEPARTMENT_PHONE]
      ,[DEPARTMENT_HEAD]
  FROM [University Analytics System].[dbo].[DEPARTMENT]