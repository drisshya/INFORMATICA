/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [COLLEGE_CODE]
      ,[COLLEGE_NAME]
      ,[COLLEGE_STREET]
      ,[COLLEGE_CITY]
      ,[COLLEGE_STATE]
      ,[COLLEGE_ZIP]
      ,[COLLEGE_PHONE]
  FROM [University Analytics System].[dbo].[COLLEGE]