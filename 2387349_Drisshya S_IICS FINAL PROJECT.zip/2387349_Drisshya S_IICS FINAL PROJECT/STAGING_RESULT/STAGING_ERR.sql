/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [CDW_P_RESULT_DEST_KEY]
      ,[ERROR_CODE]
      ,[ERR_MSG]
      ,[ERR_COLUMN_NM]
  FROM [University Analytics System].[dbo].[CDW_UAS_ERR]